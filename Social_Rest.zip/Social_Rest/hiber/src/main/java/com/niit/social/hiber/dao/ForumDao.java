package com.niit.social.hiber.dao;

import java.util.List;

import com.niit.social.hiber.model.Forum;

public interface ForumDao {

	void save(Forum forum);

	void delete(int forumId);
	void update(Forum forum);
	Forum find(int forumId);
	List<Forum> findAll();


}
