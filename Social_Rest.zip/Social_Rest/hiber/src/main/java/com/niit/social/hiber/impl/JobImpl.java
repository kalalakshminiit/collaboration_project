package com.niit.social.hiber.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.social.hiber.dao.JobDao;
import com.niit.social.hiber.model.Jobs;

@Repository
public class JobImpl implements JobDao {
	
	@Autowired
	private SessionFactory sessionFactory;


	public void save(Jobs jobs) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(jobs);
		session.getTransaction().commit();
		session.close();		
		
	}

	public void delete(int jobId) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.delete(find(jobId));
		session.getTransaction().commit();
		session.close();
		
	}

	public void update(Jobs jobs) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.update(jobs);
		session.getTransaction().commit();
		session.close();

	
		// TODO Auto-generated method stub
		
	}

	public Jobs find(int jobId) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(Jobs.class);
		criteria.add(Restrictions.eq("id", new Integer(jobId)));
		List list=criteria.list();
		session.getTransaction().commit();
		session.close();
		if(!list.isEmpty()){
			return (Jobs)list.get(0);
		}else{
			return null;
		}
		
	}

	public List<Jobs> findAll() {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(Jobs.class);		
		List<Jobs> list=(List<Jobs>) criteria.list();
		session.getTransaction().commit();
		session.close();
		if(!list.isEmpty()){
			return list;
		}else{
		
	}
		// TODO Auto-generated method stub
		return null;
	}

}



