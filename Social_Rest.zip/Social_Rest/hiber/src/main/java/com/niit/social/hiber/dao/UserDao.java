package com.niit.social.hiber.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.social.hiber.model.User;


public interface UserDao {
	void save(User entity);
	void delete(String email);
	void update(User entity);
	User find(String email);
	List<User> findAll();	
}
