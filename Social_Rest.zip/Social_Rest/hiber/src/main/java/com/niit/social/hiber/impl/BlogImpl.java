package com.niit.social.hiber.impl;



import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.social.hiber.dao.BlogDao;
import com.niit.social.hiber.model.Blog;

@Repository
public class BlogImpl implements BlogDao{
	
	@Autowired
	SessionFactory sessionFactory;
/*	
	public BlogImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	*/

	
	public void save(Blog blog) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(blog);
		session.getTransaction().commit();
		session.close();		


	}


	public void delete(int blogId) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.delete(find(blogId));
		session.getTransaction().commit();
		session.close();
	}

	public Blog find(int blogId) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(Blog.class);
		criteria.add(Restrictions.eq("id", new Integer(blogId)));
		List list=criteria.list();
		session.getTransaction().commit();
		session.close();
		if(!list.isEmpty()){
			return (Blog)list.get(0);
		}else{
			return null;
		}
	}	
		
		

	public List<Blog> findAll() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(Blog.class);		
		List<Blog> list=(List<Blog>) criteria.list();
		session.getTransaction().commit();
		session.close();
		if(!list.isEmpty()){
			return list;
		}else{
			return null;
		}

	}

	public void deleteBlog(int blogId) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.delete(find(blogId));
		session.getTransaction().commit();
		session.close();
	
		
	}

	public void update(Blog blog) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.update(blog);
		session.getTransaction().commit();
		session.close();

		// TODO Auto-generated method stub
		
	}

}


