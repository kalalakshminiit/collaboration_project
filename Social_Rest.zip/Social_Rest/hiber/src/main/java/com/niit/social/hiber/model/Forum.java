package com.niit.social.hiber.model;

import javax.persistence.Column;

//import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity(name="Forum")
@Component
public class Forum {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int forumId;
	@Column(name="title")
	private String forumTitle;
	@Column(name="description")
	private String forumDescription;
	@Column(name="datecreation")
	private String datecreation;
	@Column(name="content")
	private String content;
	
	/*private Timestamp createdAt;
	
	private Timestamp modifiedAt;
	private char status;
	*/
	public int getForumId() {
		return forumId;
	}
	public void setForumId(int forumId) {
		this.forumId = forumId;
	}
	public String getForumTitle() {
		return forumTitle;
	}
	public void setForumTitle(String forumTitle) {
		this.forumTitle = forumTitle;
	}
	public String getForumDescription() {
		return forumDescription;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDatecreation() {
		return datecreation;
	}
	public void setDatecreation(String datecreation) {
		this.datecreation = datecreation;
	}
	public void setForumDescription(String forumDescription) {
		this.forumDescription = forumDescription;
		
	}
	/*public char getStatus() {
		return status;
	}
	public void setStatus(char status) {
		this.status = status;
	}*/

}



