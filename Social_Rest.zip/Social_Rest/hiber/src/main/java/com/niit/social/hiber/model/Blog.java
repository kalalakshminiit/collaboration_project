package com.niit.social.hiber.model;

import java.io.Serializable;
//import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;


@Entity(name="Blog")
@Component
public class Blog{
	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int blogId;
	@Column(name="blogname")
    private String blogName;
	
	@Column(name="userId")
	private String userId;
	
	@Column(name="blogDescription")
    private String blogDescription;
	
	@Column(name="content")
	private String content;
	
	@Column(name="datecreation")
	private String datecreation;
	
	public int getBlogId() {
		return blogId;
	}
	public void setBlogId(int blogId) {
		this.blogId = blogId;
	}
	public String getBlogName() {
		return blogName;
	}
	public void setBlogName(String blogName) {
		this.blogName = blogName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getBlogDescription() {
		return blogDescription;
	}
	public void setBlogDescription(String blogDescription) {
		this.blogDescription = blogDescription;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDatecreation() {
		return datecreation;
	}
	public void setDatecreation(String datecreation) {
		this.datecreation = datecreation;
	}
	
}
	