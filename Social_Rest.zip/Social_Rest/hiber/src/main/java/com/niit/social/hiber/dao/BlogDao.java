package com.niit.social.hiber.dao;

import java.util.List;

import com.niit.social.hiber.model.Blog;

public interface BlogDao {
	
	void save(Blog blog);

	void delete(int blogId);
	void update(Blog blog);
	Blog find(int blogId);
	List<Blog> findAll();


}
