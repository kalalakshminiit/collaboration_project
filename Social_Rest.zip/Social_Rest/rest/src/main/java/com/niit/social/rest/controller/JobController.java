package com.niit.social.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.niit.social.hiber.dao.ForumDao;
import com.niit.social.hiber.dao.JobDao;
import com.niit.social.hiber.model.Blog;
import com.niit.social.hiber.model.Jobs;


@RestController
public class JobController {
	
	@Autowired
	JobDao jobdao;
	
	@RequestMapping(value="/job/add", method=RequestMethod.POST)
	public ResponseEntity<Void>  addJob(@RequestBody Jobs job){
		jobdao.save(job);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@RequestMapping(value="/job/getJob/{jobId}", method=RequestMethod.GET)
	public ResponseEntity<Jobs> getBlog(@PathVariable("jobId") int jobId) {
		Jobs entity= jobdao.find(jobId);
		if (entity == null) {
			return new ResponseEntity<Jobs>(HttpStatus.NOT_FOUND);
		}		
		return new  ResponseEntity<Jobs>(entity, HttpStatus.OK);
	}
	
	@RequestMapping(value="/job/deleteJob/{jobId}", method=RequestMethod.GET)
	public ResponseEntity<Void> deleteJob(@PathVariable("jobId") int jobId) {
		try{
			jobdao.delete(jobId);	
		}catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}			
		return new  ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@RequestMapping(value="/job/getAll", method=RequestMethod.GET)
	public ResponseEntity<List<Jobs>> getAll() {
		List<Jobs> entity= jobdao.findAll();
		if (entity == null) {
			return new ResponseEntity<List<Jobs>>(HttpStatus.NOT_FOUND);
		}		
		return new  ResponseEntity<List<Jobs>>(entity, HttpStatus.OK);
	}	
	
	@RequestMapping(value="/job/updateJob", method=RequestMethod.POST)
	public ResponseEntity<Void>  updateJob(@RequestBody Jobs job){
		try{
			jobdao.update(job);	
		}catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Void>(HttpStatus.OK);
	}


}
