
app.config(['$routeProvider','$locationProvider',function($routeProvider,$locationProvider){
	$routeProvider.

          when('/forum',{
        	templateUrl:'./ui/forum.html',
        	controller:'forumController',
        	 controllerAs:'forumCtrl',
        	 
          }).

          when('/',{
        	templateUrl:'./ui/main.html',
        	controller:'registerController',
       	    controllerAs:'registerCtrl',
       	 
        
        	 
          }).
          

          when('/Blog',{
        	templateUrl:'./ui/Blog.html',
        	controller:'blogController',
        	 controllerAs:'blogCtrl',
        	 
          }).

            when('/add',{
        	templateUrl:'./ui/addblog.html',
        	controller:'blogController',
        	 controllerAs:'blogCtrl',
        	 
          }).
          

          when('/adf',{
        	templateUrl:'./ui/addforum.html',
        	controller:'forumController',
        	 controllerAs:'forumCtrl',
        	 
          }).
          

          when('/job',{
        	templateUrl:'./ui/job.html',
        	controller:'jobController',
        	 controllerAs:'jobCtrl',
        	 
          }).
          when('/login',{
          	templateUrl:'./ui/login.html',
          	controller:'loginController',
          	 controllerAs:'loginCtrl',
          	 
            }).
            
              when('/chat',{
                  templateUrl:'./ui/chat.html',
                  /*controller:HomeController,
                  controllerAs:homeCtrl*/
              }).
                when('/news',{
                  templateUrl:'./ui/news.html',
                  /*controller:HomeController,
                  controllerAs:homeCtrl*/
              }).
                              
              
              when('/listBlog',{
              templateUrl:'./ui/listBlog.html',
              controller:'blogController',
              controllerAs:'blogCtrl'
          }).
              when('/viewBlog',{
              templateUrl:'./ui/viewBlog.html',
              controller:'blogController',
              controllerAs:'blogCtrl'
          }).
              when('/updateBlog',{
              templateUrl:'./ui/updateBlog.html',
              controller:'blogController',
              controllerAs:'blogCtrl'
          }).
              when('/listForum',{
              templateUrl:'./ui/listForum.html',
              controller:'forumController',
              controllerAs:'forumCtrl'
          }).
              when('/viewForum',{
              templateUrl:'./ui/viewForum.html',
              controller:'forumController',
              controllerAs:'forumCtrl'
          }).
              when('/updateForum',{
              templateUrl:'./ui/updateForum.html',
              controller:'forumController',
              controllerAs:'forumCtrl'
          }).
              when('/listJob',{
              templateUrl:'./ui/listJob.html',
              controller:'jobController',
              controllerAs:'jobCtrl'
          }).
              when('/viewJob',{
              templateUrl:'./ui/viewJob.html',
              controller:'jobController',
              controllerAs:'blogCtrl'
          }).
              when('/updateJob',{
              templateUrl:'./ui/updateJob.html',
              controller:'jobController',
              controllerAs:'jobCtrl'
          })

          }]);

              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              

             




