app.factory('registerFactory', ['$http','$q','$rootScope',function($http,$q,$rootScope){
	var address = 'http://localhost:8013/rest/';
	var addressForRegister = 'http://localhost:8013/rest/user/add';
	var self=this;
	return {
		registerUser:registerUser		
	};
	function registerUser(user){
		var deferred = $q.defer();
		$http.post(addressForRegister,user).
		then(function(response){
			deferred.resolve(response.data);
		},function(errResponse){
			deferred.reject(errResponse);
		});
		alert("Form Submitted " + user.email);
		return deferred.promise;
	};
	
}]);
/*app.factory('registerFactory', ['$http','$q','$rootScope',function($http,$q,$rootScope){
	var address = 'http://localhost:8060/rest/';
	var addressForRegister = 'http://localhost:8060/rest/user/add';
	var self=this;
	return {
		registerUser:registerUser,
		loginUser:loginUser,
		logout:logout,
	};
	function registerUser(user){
		var deferred = $q.defer();
		$http.post(addressForRegister,user).
		then(function(response){
			deferred.resolve(response.data);
		},function(errResponse){
			deferred.reject(errResponse);
		});
		alert("Form Submitted " + user.email);
		return deferred.promise;
	};
	

	 function loginUser(values){

	 	var deferred  = $q.defer();
	 	$http.post(address,values).
	 	then(function(response){
	 		deferred.resolve(response.data);
		},function(errResponse){
			deferred.reject(errResponse);
	 	});
	 	return deferred.promise;	
	}
	
	 
	 function logout(userId){
			var deferred = $q.defer();
			$http.put('http://localhost:8080/socials/logout/'+userId)
			.then(function (response) {
				deferred.resolve(response);
			},
			function(errResponse){
				deferred.reject(errResponse);
			});
			return deferred.promise;
		}
	 
}]);*/