app.factory('loginFactory', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    var address = 'http://localhost:8013/rest/';
    var addressForRegister = 'http://localhost:8013/rest/user/validate';
    var self=this;
    return {
        validateUser:validateUser        
    };
    function validateUser(user){
        var deferred = $q.defer();
        $http.post(addressForRegister,user).
        then(function(response){
            deferred.resolve(response.data);
            alert("User Found " + user.email);
        },function(errResponse){
            deferred.reject(errResponse);
            alert("User Not Found " + user.email);
        });        
        return deferred.promise;
    };
    
}]);


