app.factory('jobFactory', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    var address = 'http://localhost:8013/rest/';
    var addressForJob = 'http://localhost:8013/rest/job/add';
    var addressForGetAllJobs= 'http://localhost:8013/rest/job/getAll';
    var addressForGetJob= 'http://localhost:8013/rest/job/getJob';
    var addressForDeleteJob= 'http://localhost:8013/rest/job/deleteJob';
    var addressForUpdateJob= 'http://localhost:8013/rest/job/updateJob';

    var self=this;
    return {
        registerJob:registerJob,
        fetchAllJobs:fetchAllJobs,
        fetchJob:fetchJob,
        deleteJob:deleteJob,
        updateJob:updateJob        
    };
    function registerJob(job){
        var deferred = $q.defer();
        $http.post(addressForJob,job).
        then(function(response){
            deferred.resolve(response.data);
        },function(errResponse){
            deferred.reject(errResponse);
        });
        alert("Job Submitted " + job.jobTitle);
        return deferred.promise;
    };
    
    function fetchAllJobs(){
        //Create a deferred object
        var deferred = $q.defer();
        //var value = $rootScope.username+":"+$rootScope.password;
        //console.log(value);        
        $http.get(addressForGetAllJobs)
        .then(function(response){
            deferred.resolve(response.data);
        },
        function(errResponse){
            console.error('Error fetching jobs');
            deferred.reject(errResponse);
        });
        return deferred.promise;     
    };

    function fetchJob(jobId){        
        var deferred = $q.defer();        
        $http.get(addressForGetJob+"/"+jobId)
        .then(function(response){
            deferred.resolve(response.data);            
        },
        function(errResponse){
            console.error('Error fetching jobs');
            deferred.reject(errResponse);
        });
        return deferred.promise;     
    };
    function deleteJob(jobId){        
        var deferred = $q.defer();        
        $http.get(addressForDeleteJob+"/"+jobId)
        .then(function(response){
            deferred.resolve(response.data);            
        },
        function(errResponse){
            console.error('Error fetching jobs');
            deferred.reject(errResponse);
        });
        return deferred.promise;     
    };

    function updateJob(job){
        var deferred = $q.defer();
        $http.post(addressForUpdateJob,job). 
        then(function(response){
            deferred.resolve(response.data);
        },function(errResponse){
            deferred.reject(errResponse);
        });
        
        return deferred.promise;
    };

    
    
}]);
