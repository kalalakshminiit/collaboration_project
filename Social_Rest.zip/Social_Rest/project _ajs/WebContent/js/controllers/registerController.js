app.controller('registerController',['registerFactory','$rootScope','$location','$scope','$localStorage', function(registerFactory, $rootScope,$location,$scope,$localStorage){
	var self=this;
	self.user={email:'',name:'',role:'',contact:'',password:'',status:'', enabled:''};
	self.registerUser=function(){
		self.user.status=true;
		self.user.enabled=true;
		registerFactory.registerUser(self.user);
	}	
}]);

/*app.controller('registerController',['registerFactory','$rootScope','$location','$scope','$localStorage', function(registerFactory, $rootScope,$location,$scope,$localStorage){
	var self=this;
	self.user={email:'',name:'',role:'',contact:'',password:'',status:'', enabled:''};
	self.registerUser=function(){
		self.user.status=true;
		self.user.enabled=true;
		
		
		self.client = {email:'',password:''};
		self.loginError=false;
		self.failed = false;
	}	
	
	

	function loginUser(client){
		//debugger;
		var values = {email:email,password:password}
registerFactory.loginUser(client).
		then(function(data){
			console.log("login successful");
			console.log(data);
			$rootScope.customUser.data = data;
			$rootScope.customUser.status= true;
			$location.path('/');

			
		$scope.$storage.client = data;
			$scope.$storage.status = true;
			console.log($scope.$storage.client);
			delete $scope.$storage.data;
	
		},function(errResponse){
			console.error(errResponse.status);
	});		
	resetLoginFields();
}


	
	self.logout=function(){
		//debugger;
		registerFactory.logout($rootScope.client.userId);
		$localStorage.$reset();
		delete $rootScope.client;
$location.path("/");
	};


function reset(){
	self.user={registerEmail:'',registerContact:'',registerName:'',registerPassword:'',registerRole:''};
};

function resetLoginFields(){
	self.client={email:'',password:''};
};

}]);


*/